import React from 'react';
import { Building, Calendar, MapPin, Star, CheckCircle } from 'lucide-react';
import type { RecognitionResult } from '../types/ai';

interface RecognitionResultProps {
  result: RecognitionResult | null;
  isLoading?: boolean;
}

export const RecognitionResultCard: React.FC<RecognitionResultProps> = ({
  result,
  isLoading = false,
}) => {
  if (isLoading) {
    return (
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-700 rounded w-3/4"></div>
          <div className="h-4 bg-gray-700 rounded w-1/2"></div>
          <div className="space-y-2">
            <div className="h-4 bg-gray-700 rounded"></div>
            <div className="h-4 bg-gray-700 rounded"></div>
            <div className="h-4 bg-gray-700 rounded w-5/6"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700 text-center">
        <Building size={48} className="mx-auto mb-4 text-gray-600" />
        <p className="text-gray-400">
          上传古建筑图片后，AI 将自动识别建筑信息
        </p>
      </div>
    );
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case '皇宫':
        return 'bg-imperial-red text-white';
      case '民居':
        return 'bg-amber-600 text-white';
      case '官府':
        return 'bg-blue-600 text-white';
      case '桥梁':
        return 'bg-cyan-600 text-white';
      default:
        return 'bg-gray-600 text-white';
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 border border-imperial-gold/30">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-2xl font-bold text-imperial-gold mb-1">
            {result.name}
          </h3>
          <span
            className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(
              result.category
            )}`}
          >
            {result.category}
          </span>
        </div>
        <div className="flex items-center text-imperial-gold">
          <Star size={20} className="mr-1" />
          <span className="font-bold">{(result.confidence * 100).toFixed(0)}%</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="flex items-center text-gray-300">
          <Calendar size={18} className="mr-2 text-imperial-gold" />
          <span>{result.era} · {result.year}</span>
        </div>
        <div className="flex items-center text-gray-300">
          <MapPin size={18} className="mr-2 text-imperial-gold" />
          <span>{result.location}</span>
        </div>
      </div>

      {result.features.length > 0 && (
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-400 mb-2">建筑特点</h4>
          <div className="flex flex-wrap gap-2">
            {result.features.map((feature, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-imperial-gold/20 text-imperial-gold rounded-full text-sm"
              >
                {feature}
              </span>
            ))}
          </div>
        </div>
      )}

      {result.description && (
        <div>
          <h4 className="text-sm font-medium text-gray-400 mb-2">简介</h4>
          <p className="text-gray-300 leading-relaxed">{result.description}</p>
        </div>
      )}

      <div className="mt-4 pt-4 border-t border-gray-700 flex items-center text-sm text-gray-500">
        <CheckCircle size={16} className="mr-2 text-green-500" />
        <span>AI 识别完成 · 结果仅供参考</span>
      </div>
    </div>
  );
};