import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { MapPin, Calendar, Building2, ArrowUpRight, X } from 'lucide-react';

const withBase = (filePath: string) => `${import.meta.env.BASE_URL}${filePath.replace(/^\/+/, '')}`;

interface ShowcaseItem {
  id: string;
  name: string;
  category: string;
  era: string;
  year: string;
  location: string;
  description: string;
  story: string;
  significance: string;
  focusPoints: string[];
  features: string[];
  color: string;
  image: string;
}

const showcases: ShowcaseItem[] = [
  {
    id: 'forbidden-city-taihe',
    name: '故宫太和殿',
    category: '皇宫',
    era: '明清',
    year: '1420年',
    location: '北京',
    description: '中国现存最大的木结构大殿，位于紫禁城南北主轴线的显要位置，是明清两代皇帝举行大典的场所。',
    story: '太和殿始建于明永乐年间，后历经火灾与重建，清代形成今天所见形制，是国家礼仪与王朝权力的核心舞台。',
    significance: '作为宫殿建筑最高等级范式，太和殿集中呈现了台基、柱网、屋顶与彩画系统的协同。',
    focusPoints: ['先看台基高度与殿身比例关系', '再看重檐与斗拱的承托层次', '最后观察中轴空间如何组织仪式动线'],
    features: ['重檐庑殿顶', '黄色琉璃瓦', '和玺彩画'],
    color: 'from-red-600 to-red-800',
    image: withBase('data/images/forbidden-city-taihe.jpg'),
  },
  {
    id: 'zhaozhou-bridge',
    name: '赵州桥',
    category: '桥梁',
    era: '隋代',
    year: '605年',
    location: '河北赵县',
    description: '世界上现存最古老、保存最完整的单孔敞肩石拱桥，距今已有1400多年历史，由著名工匠李春设计建造。',
    story: '赵州桥建于隋代，是中国古代桥梁工程的重要里程碑，以创新的敞肩结构显著提高了排洪与减重能力。',
    significance: '其“大拱+小拱”的组合体现了古代工程师对受力与材料效率的深刻理解。',
    focusPoints: ['侧视观察拱圈曲线和跨度比例', '注意敞肩小拱的减重与泄洪作用', '对比桥墩与桥面的受力传递路径'],
    features: ['单孔敞肩', '大拱加小拱', '世界最古老'],
    color: 'from-cyan-600 to-cyan-800',
    image: withBase('data/images/zhaozhou-bridge.jpg'),
  },
  {
    id: 'chengqi-tulou',
    name: '福建土楼',
    category: '民居',
    era: '明清',
    year: '12-20世纪',
    location: '福建',
    description: '福建客家人特有的民居建筑形式，以其独特的圆形或方形夯土建筑闻名于世，聚族而居，具有防御功能。',
    story: '土楼随着客家聚族生活需求逐步成熟，形成“防御+居住+宗族组织”三位一体的建筑体系。',
    significance: '承启楼代表了夯土围合、木构内廊与公共院落空间的高度整合，是地域材料智慧的典型案例。',
    focusPoints: ['看外圈夯土墙厚度与开窗控制', '看内廊如何组织垂直交通与邻里关系', '看中心院落如何承担公共活动'],
    features: ['圆形土楼', '夯土建筑', '防御功能'],
    color: 'from-amber-600 to-amber-800',
    image: withBase('data/images/chengqi-tulou.jpg'),
  },
  {
    id: 'beijing-siheyuan',
    name: '四合院',
    category: '民居',
    era: '明清',
    year: '14-20世纪',
    location: '北京',
    description: '中国传统民居建筑的代表，以院落为中心，四面围合的建筑形式，体现了中国传统的中轴对称布局。',
    story: '四合院在长期城市生活中形成稳定形制，通过门、院、房的层层递进实现礼序、私密与日常生活平衡。',
    significance: '它是北方院落住宅的典型母题，反映了朝向、气候、家庭结构与礼制观念对空间的共同塑造。',
    focusPoints: ['先看正房与厢房的等级关系', '再看院落尺度与采光通风逻辑', '最后看影壁与门道如何组织视线与动线'],
    features: ['中轴对称', '院落布局', '四面建房'],
    color: 'from-emerald-600 to-emerald-800',
    image: withBase('data/images/beijing-siheyuan.jpg'),
  },
];

const FALLBACK_IMAGE = withBase('data/images/forbidden-city-wumen.jpg');

export const ShowcaseSection: React.FC = () => {
  const [activeShowcase, setActiveShowcase] = useState<ShowcaseItem | null>(null);

  return (
    <section id="showcase" className="relative scroll-mt-28 py-32 bg-black overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div className="text-center mb-20">
          <motion.span className="inline-block px-4 py-2 mb-6 text-sm font-medium text-amber-400 bg-amber-400/10 border border-amber-400/20 rounded-full">
            经典案例
          </motion.span>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            探索 <span className="text-gradient-gold">建筑瑰宝</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            从皇宫到民居，从桥梁到园林，发现中华建筑的独特魅力
          </p>
        </motion.div>

        {/* Showcase Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {showcases.map((item) => (
            <motion.div
              key={item.id}
              className="group relative"
            >
              <div className="relative overflow-hidden rounded-2xl bg-white/[0.02] border border-white/5 hover:border-amber-500/30 transition-all duration-500">
                {/* Cover Image */}
                <div className={`relative h-64 bg-gradient-to-br ${item.color} overflow-hidden`}>
                  <img
                    src={item.image}
                    alt={`${item.name} 实景图`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    onError={(event) => {
                      event.currentTarget.src = FALLBACK_IMAGE;
                    }}
                  />

                  {/* Pattern Overlay */}
                  <div className="absolute inset-0 opacity-20" style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40'/%3E%3C/g%3E%3C/svg%3E")`,
                  }} />

                  {/* Building Icon */}
                  <div className="absolute inset-0 flex items-center justify-center bg-black/15">
                    <Building2 className="w-24 h-24 text-white/30" />
                  </div>

                  {/* Category Badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-black/50 backdrop-blur-sm text-white text-sm rounded-full">
                      {item.category}
                    </span>
                  </div>

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <motion.button
                      type="button"
                      onClick={() => setActiveShowcase(item)}
                      className="flex items-center gap-2 px-6 py-3 bg-white text-black font-semibold rounded-full"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      查看详情
                      <ArrowUpRight className="w-4 h-4" />
                    </motion.button>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
                    {item.name}
                  </h3>

                  <div className="flex flex-wrap gap-4 mb-4 text-sm text-gray-400">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{item.era} · {item.year}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>{item.location}</span>
                    </div>
                  </div>

                  <p className="text-gray-400 text-sm leading-relaxed mb-4">
                    {item.description}
                  </p>

                  {/* Features */}
                  <div className="flex flex-wrap gap-2">
                    {item.features.map((feature) => (
                      <span
                        key={feature}
                        className="px-3 py-1 bg-amber-500/10 text-amber-400 text-xs rounded-full border border-amber-500/20"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <AnimatePresence>
          {activeShowcase && (
            <motion.div
              className="fixed inset-0 z-[90] bg-black/80 backdrop-blur-sm px-4 py-8 flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveShowcase(null)}
            >
              <motion.div
                className="w-full max-w-5xl max-h-[88vh] overflow-y-auto rounded-2xl overflow-hidden border border-white/10 bg-[#0b0f1c] shadow-2xl"
                initial={{ opacity: 0, y: 24, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 12, scale: 0.98 }}
                transition={{ duration: 0.22 }}
                onClick={(event) => event.stopPropagation()}
              >
                <div className="grid grid-cols-1 md:grid-cols-2">
                  <div className="relative h-72 md:h-full min-h-[20rem]">
                    <img
                      src={activeShowcase.image}
                      alt={`${activeShowcase.name} 详情图`}
                      className="h-full w-full object-cover"
                      onError={(event) => {
                        event.currentTarget.src = FALLBACK_IMAGE;
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/10" />
                    <span className="absolute top-4 left-4 px-3 py-1 rounded-full text-sm bg-black/55 text-white border border-white/20">
                      {activeShowcase.category}
                    </span>
                  </div>

                  <div className="p-6 md:p-8">
                    <div className="flex items-start justify-between gap-4">
                      <h3 className="text-2xl md:text-3xl font-bold text-white">{activeShowcase.name}</h3>
                      <button
                        type="button"
                        onClick={() => setActiveShowcase(null)}
                        className="p-2 rounded-full border border-white/20 text-gray-200 hover:text-white hover:border-white/40"
                        aria-label="关闭详情"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-4 text-sm text-gray-300">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-4 h-4 text-amber-300" />
                        <span>{activeShowcase.era} · {activeShowcase.year}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-4 h-4 text-amber-300" />
                        <span>{activeShowcase.location}</span>
                      </div>
                    </div>

                    <p className="mt-5 text-gray-300 leading-relaxed">{activeShowcase.description}</p>

                    <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">
                        <p className="text-[11px] text-gray-400">建筑类型</p>
                        <p className="mt-1 text-sm text-white">{activeShowcase.category}</p>
                      </div>
                      <div className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">
                        <p className="text-[11px] text-gray-400">主要年代</p>
                        <p className="mt-1 text-sm text-white">{activeShowcase.year}</p>
                      </div>
                      <div className="rounded-lg border border-white/10 bg-white/5 px-3 py-2">
                        <p className="text-[11px] text-gray-400">所在地区</p>
                        <p className="mt-1 text-sm text-white">{activeShowcase.location}</p>
                      </div>
                    </div>

                    <div className="mt-5 rounded-xl border border-amber-400/20 bg-amber-500/5 px-4 py-3">
                      <p className="text-xs text-amber-200">建筑价值</p>
                      <p className="mt-1 text-sm text-gray-200 leading-relaxed">{activeShowcase.significance}</p>
                    </div>

                    <div className="mt-4 rounded-xl border border-white/10 bg-white/5 px-4 py-3">
                      <p className="text-xs text-sky-200">历史脉络</p>
                      <p className="mt-1 text-sm text-gray-200 leading-relaxed">{activeShowcase.story}</p>
                    </div>

                    <div className="mt-6 flex flex-wrap gap-2">
                      {activeShowcase.features.map((feature) => (
                        <span
                          key={`${activeShowcase.id}-${feature}`}
                          className="px-3 py-1 text-xs rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-200"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>

                    <div className="mt-5">
                      <p className="text-sm font-semibold text-white">推荐观察点</p>
                      <ol className="mt-2 space-y-1.5 text-sm text-gray-300">
                        {activeShowcase.focusPoints.map((point, index) => (
                          <li key={`${activeShowcase.id}-focus-${point}`} className="flex gap-2">
                            <span className="text-amber-300">{index + 1}.</span>
                            <span>{point}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};
