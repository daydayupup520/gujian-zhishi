import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Building2, Sparkles, History, Camera } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-black/80 backdrop-blur-xl border-b border-imperial-gold/30'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <motion.div
            className="flex items-center gap-3"
            whileHover={{ scale: 1.02 }}
          >
            <div className="relative">
              <motion.div
                className="w-12 h-12 bg-gradient-to-br from-imperial-gold to-imperial-red rounded-xl flex items-center justify-center shadow-lg"
                animate={{
                  boxShadow: [
                    '0 0 20px rgba(212, 175, 55, 0.3)',
                    '0 0 40px rgba(212, 175, 55, 0.5)',
                    '0 0 20px rgba(212, 175, 55, 0.3)',
                  ],
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Building2 className="w-6 h-6 text-white" />
              </motion.div>
              <motion.div
                className="absolute -inset-1 bg-gradient-to-r from-imperial-gold to-imperial-red rounded-xl blur opacity-30"
                animate={{ opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-imperial-gold via-white to-imperial-gold bg-clip-text text-transparent">
                古建智识
              </h1>
              <p className="text-xs text-gray-400">AI驱动的古建筑识别系统</p>
            </div>
          </motion.div>

          {/* Nav Items */}
          <div className="hidden md:flex items-center gap-6">
            {[
              { icon: Camera, label: '智能识别' },
              { icon: Building2, label: '3D展示' },
              { icon: History, label: '知识库' },
            ].map((item, index) => (
              <motion.div
                key={item.label}
                className="flex items-center gap-2 text-gray-300 hover:text-imperial-gold cursor-pointer transition-colors"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                <item.icon className="w-4 h-4" />
                <span className="text-sm font-medium">{item.label}</span>
              </motion.div>
            ))}
          </div>

          {/* AI Badge */}
          <motion.div
            className="flex items-center gap-2 px-4 py-2 bg-imperial-gold/10 border border-imperial-gold/30 rounded-full"
            whileHover={{ scale: 1.05 }}
            animate={{
              borderColor: ['rgba(212, 175, 55, 0.3)', 'rgba(212, 175, 55, 0.6)', 'rgba(212, 175, 55, 0.3)'],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Sparkles className="w-4 h-4 text-imperial-gold" />
            <span className="text-sm font-medium text-imperial-gold">智谱AI</span>
          </motion.div>
        </div>
      </div>
    </motion.nav>
  );
};