import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Calendar, Building2, ArrowRightLeft, Trophy, Scale, ChevronDown } from 'lucide-react';

interface BuildingData {
  id: string;
  name: string;
  category: string;
  era: string;
  year: string;
  location: string;
  description: string;
  features: string[];
  image: string;
  structuralScore: number;
  preservationScore: number;
  digitalValue: number;
  riskLevel: '高风险' | '中风险' | '可控';
}

interface BuildingComparisonProps {
  currentBuilding?: BuildingData | null;
}

const withBase = (filePath: string) =>
  `${import.meta.env.BASE_URL}${filePath.replace(/^\/+/, '')}`;

const BUILDING_DATABASE: BuildingData[] = [
  {
    id: 'forbidden-city-taihe',
    name: '故宫太和殿',
    category: '皇宫',
    era: '明清',
    year: '1420年',
    location: '北京',
    description: '中国现存最大的木结构大殿，位于紫禁城南北主轴线的显要位置。',
    features: ['重檐庑殿顶', '黄色琉璃瓦', '和玺彩画'],
    image: withBase('data/images/forbidden-city-taihe.jpg'),
    structuralScore: 72,
    preservationScore: 89,
    digitalValue: 94,
    riskLevel: '中风险',
  },
  {
    id: 'zhaozhou-bridge',
    name: '赵州桥',
    category: '桥梁',
    era: '隋代',
    year: '605年',
    location: '河北赵县',
    description: '世界上现存最古老、保存最完整的单孔敞肩石拱桥。',
    features: ['单孔敞肩', '大拱加小拱', '世界最古老'],
    image: withBase('data/images/zhaozhou-bridge.jpg'),
    structuralScore: 68,
    preservationScore: 91,
    digitalValue: 88,
    riskLevel: '中风险',
  },
  {
    id: 'chengqi-tulou',
    name: '福建土楼',
    category: '民居',
    era: '明清',
    year: '12-20世纪',
    location: '福建',
    description: '福建客家人特有的民居建筑形式，以独特的圆形夯土建筑闻名。',
    features: ['圆形土楼', '夯土建筑', '防御功能'],
    image: withBase('data/images/chengqi-tulou.jpg'),
    structuralScore: 78,
    preservationScore: 84,
    digitalValue: 82,
    riskLevel: '高风险',
  },
  {
    id: 'beijing-siheyuan',
    name: '四合院',
    category: '民居',
    era: '明清',
    year: '14-20世纪',
    location: '北京',
    description: '中国传统民居建筑的代表，以院落为中心四面围合。',
    features: ['中轴对称', '院落布局', '四面建房'],
    image: withBase('data/images/beijing-siheyuan.jpg'),
    structuralScore: 45,
    preservationScore: 76,
    digitalValue: 71,
    riskLevel: '可控',
  },
  {
    id: 'pingyao-yamen',
    name: '平遥县衙',
    category: '官府',
    era: '明清',
    year: '明清',
    location: '山西平遥',
    description: '保存完整的县级官署建筑群，体现古代行政空间组织。',
    features: ['中轴对称', '大堂二堂', '仪门甬道'],
    image: withBase('data/images/pingyao-yamen.jpg'),
    structuralScore: 62,
    preservationScore: 87,
    digitalValue: 79,
    riskLevel: '中风险',
  },
  {
    id: 'wuting-bridge',
    name: '五亭桥',
    category: '桥梁',
    era: '清',
    year: '1757年',
    location: '江苏扬州',
    description: '瘦西湖标志性桥梁，以桥亭组合和多拱结构形成独特景观。',
    features: ['桥亭结合', '多拱石桥', '园林景观'],
    image: withBase('data/images/wuting-bridge.jpg'),
    structuralScore: 55,
    preservationScore: 82,
    digitalValue: 86,
    riskLevel: '可控',
  },
];

export const BuildingComparison: React.FC<BuildingComparisonProps> = ({
  currentBuilding,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [leftBuildingId, setLeftBuildingId] = useState<string>(
    currentBuilding?.id ?? BUILDING_DATABASE[0].id
  );
  const [rightBuildingId, setRightBuildingId] = useState<string>(
    BUILDING_DATABASE[1].id
  );

  const leftBuilding = useMemo(
    () => BUILDING_DATABASE.find((b) => b.id === leftBuildingId) ?? BUILDING_DATABASE[0],
    [leftBuildingId]
  );
  const rightBuilding = useMemo(
    () => BUILDING_DATABASE.find((b) => b.id === rightBuildingId) ?? BUILDING_DATABASE[1],
    [rightBuildingId]
  );

  const comparison = useMemo(() => {
    const scoreDiff = leftBuilding.structuralScore - rightBuilding.structuralScore;
    const preservationDiff = leftBuilding.preservationScore - rightBuilding.preservationScore;
    const digitalDiff = leftBuilding.digitalValue - rightBuilding.digitalValue;

    const advantages = [];
    if (scoreDiff < -10) advantages.push(`${rightBuilding.name}结构更稳定`);
    if (preservationDiff < -10) advantages.push(`${rightBuilding.name}保护优先级更高`);
    if (digitalDiff < -10) advantages.push(`${rightBuilding.name}数字化展示价值更高`);
    if (advantages.length === 0) advantages.push('两建筑保护需求相近，建议联合申遗或建立区域保护联盟');

    return {
      scoreDiff,
      preservationDiff,
      digitalDiff,
      advantages,
      winner:
        leftBuilding.preservationScore > rightBuilding.preservationScore
          ? leftBuilding.name
          : rightBuilding.name,
    };
  }, [leftBuilding, rightBuilding]);

  const handleSwap = () => {
    setLeftBuildingId(rightBuildingId);
    setRightBuildingId(leftBuildingId);
  };

  return (
    <div className="mt-10">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-6 py-4 rounded-xl border border-white/10 bg-gradient-to-r from-amber-500/10 to-cyan-500/10 hover:from-amber-500/20 hover:to-cyan-500/20 transition-all"
      >
        <div className="flex items-center gap-3">
          <Scale className="w-6 h-6 text-amber-400" />
          <div className="text-left">
            <h3 className="text-lg font-bold text-white">同类建筑对比分析</h3>
            <p className="text-sm text-gray-400">
              并排比较两栋建筑的风险等级、保护优先级与数字化价值
            </p>
          </div>
        </div>
        <ChevronDown
          className={`w-5 h-5 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-4 rounded-2xl border border-white/10 bg-[#0a1020] p-6">
              {/* Building Selectors */}
              <div className="flex flex-col md:flex-row items-center gap-4 mb-6">
                <div className="flex-1 w-full">
                  <label htmlFor="left-building-selector" className="text-xs text-gray-400 mb-1 block">左侧建筑</label>
                  <select
                    id="left-building-selector"
                    value={leftBuildingId}
                    onChange={(e) => setLeftBuildingId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-white/10 bg-black/40 text-white text-sm"
                  >
                    {BUILDING_DATABASE.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name} ({b.category})
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleSwap}
                  className="p-2 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 text-gray-300"
                  title="交换位置"
                >
                  <ArrowRightLeft className="w-4 h-4" />
                </button>

                <div className="flex-1 w-full">
                  <label htmlFor="right-building-selector" className="text-xs text-gray-400 mb-1 block">右侧建筑</label>
                  <select
                    id="right-building-selector"
                    value={rightBuildingId}
                    onChange={(e) => setRightBuildingId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-white/10 bg-black/40 text-white text-sm"
                  >
                    {BUILDING_DATABASE.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name} ({b.category})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Comparison Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Left Building */}
                <div className="rounded-xl border border-white/10 bg-black/30 overflow-hidden">
                  <div className="relative h-48">
                    <img
                      src={leftBuilding.image}
                      alt={leftBuilding.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <span className="px-2 py-1 rounded-full text-xs bg-amber-500/20 text-amber-200 border border-amber-500/30">
                        {leftBuilding.category}
                      </span>
                      <h4 className="mt-2 text-xl font-bold text-white">{leftBuilding.name}</h4>
                    </div>
                  </div>
                  <div className="p-4 space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-300">
                      <Calendar className="w-4 h-4 text-amber-400" />
                      <span>
                        {leftBuilding.era} · {leftBuilding.year}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-300">
                      <MapPin className="w-4 h-4 text-amber-400" />
                      <span>{leftBuilding.location}</span>
                    </div>
                    <p className="text-sm text-gray-400 line-clamp-2">{leftBuilding.description}</p>

                    {/* Scores */}
                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/10">
                      <div className="text-center">
                        <p className="text-xs text-gray-500">结构压力</p>
                        <p
                          className={`text-lg font-bold ${
                            leftBuilding.structuralScore >= comparison.scoreDiff + rightBuilding.structuralScore
                              ? 'text-rose-400'
                              : 'text-emerald-400'
                          }`}
                        >
                          {leftBuilding.structuralScore}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-gray-500">保护优先级</p>
                        <p className="text-lg font-bold text-sky-400">{leftBuilding.preservationScore}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-gray-500">数字价值</p>
                        <p className="text-lg font-bold text-amber-400">{leftBuilding.digitalValue}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Building */}
                <div className="rounded-xl border border-white/10 bg-black/30 overflow-hidden">
                  <div className="relative h-48">
                    <img
                      src={rightBuilding.image}
                      alt={rightBuilding.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <span className="px-2 py-1 rounded-full text-xs bg-cyan-500/20 text-cyan-200 border border-cyan-500/30">
                        {rightBuilding.category}
                      </span>
                      <h4 className="mt-2 text-xl font-bold text-white">{rightBuilding.name}</h4>
                    </div>
                  </div>
                  <div className="p-4 space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-300">
                      <Calendar className="w-4 h-4 text-cyan-400" />
                      <span>
                        {rightBuilding.era} · {rightBuilding.year}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-300">
                      <MapPin className="w-4 h-4 text-cyan-400" />
                      <span>{rightBuilding.location}</span>
                    </div>
                    <p className="text-sm text-gray-400 line-clamp-2">{rightBuilding.description}</p>

                    {/* Scores */}
                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/10">
                      <div className="text-center">
                        <p className="text-xs text-gray-500">结构压力</p>
                        <p
                          className={`text-lg font-bold ${
                            rightBuilding.structuralScore >= leftBuilding.structuralScore
                              ? 'text-rose-400'
                              : 'text-emerald-400'
                          }`}
                        >
                          {rightBuilding.structuralScore}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-gray-500">保护优先级</p>
                        <p className="text-lg font-bold text-sky-400">{rightBuilding.preservationScore}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-xs text-gray-500">数字价值</p>
                        <p className="text-lg font-bold text-amber-400">{rightBuilding.digitalValue}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Analysis Result */}
              <div className="mt-6 rounded-xl border border-amber-400/20 bg-amber-500/5 p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Trophy className="w-5 h-5 text-amber-400" />
                  <h4 className="text-lg font-semibold text-white">对比结论</h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="rounded-lg bg-black/30 p-3">
                    <p className="text-xs text-gray-400">保护优先级差异</p>
                    <p
                      className={`text-lg font-bold ${
                        Math.abs(comparison.preservationDiff) > 10
                          ? 'text-amber-400'
                          : 'text-gray-400'
                      }`}
                    >
                      {comparison.preservationDiff > 0 ? '+' : ''}
                      {comparison.preservationDiff}
                    </p>
                    <p className="text-xs text-gray-500">
                      {leftBuilding.name} 更{comparison.preservationDiff > 0 ? '高' : '低'}
                    </p>
                  </div>
                  <div className="rounded-lg bg-black/30 p-3">
                    <p className="text-xs text-gray-400">数字化价值差异</p>
                    <p
                      className={`text-lg font-bold ${
                        Math.abs(comparison.digitalDiff) > 10 ? 'text-amber-400' : 'text-gray-400'
                      }`}
                    >
                      {comparison.digitalDiff > 0 ? '+' : ''}
                      {comparison.digitalDiff}
                    </p>
                    <p className="text-xs text-gray-500">
                      {leftBuilding.name} 更{comparison.digitalDiff > 0 ? '高' : '低'}
                    </p>
                  </div>
                  <div className="rounded-lg bg-black/30 p-3">
                    <p className="text-xs text-gray-400">建议优先保护</p>
                    <p className="text-lg font-bold text-emerald-400">{comparison.winner}</p>
                    <p className="text-xs text-gray-500">综合评分更高</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-semibold text-amber-200">核心优势分析：</p>
                  <ul className="space-y-1">
                    {comparison.advantages.map((adv, idx) => (
                      <li key={`${leftBuilding.id}-${rightBuilding.id}-adv-${idx}`} className="text-sm text-gray-300 flex items-start gap-2">
                        <Building2 className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                        {adv}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-4 p-3 rounded-lg bg-black/30 border-l-4 border-amber-400">
                  <p className="text-sm text-gray-300">
                    <span className="text-amber-400 font-semibold">分析建议：</span>
                    通过对比{leftBuilding.name}与{rightBuilding.name}，我们发现
                    {comparison.preservationDiff > 10
                      ? `${leftBuilding.name}需要更紧急的保护措施`
                      : comparison.preservationDiff < -10
                        ? `${rightBuilding.name}需要更紧急的保护措施`
                        : '两建筑保护优先级相近，可制定联合保护策略'}
                    。这种基于数据驱动的古建筑比较研究方法，为遗产保护决策提供了科学依据。
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
