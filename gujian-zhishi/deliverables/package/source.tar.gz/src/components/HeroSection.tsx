import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Camera, Brain, Box } from 'lucide-react';

interface HeroSectionProps {
  onScrollToApp: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onScrollToApp }) => {
  const features = [
    { icon: Camera, title: '智能识别', desc: 'AI识别古建筑类型、年代、风格', color: 'from-blue-500 to-cyan-500' },
    { icon: Box, title: '3D可视化', desc: '沉浸式浏览古代建筑之美', color: 'from-imperial-gold to-orange-500' },
    { icon: Brain, title: '知识讲解', desc: '深入了解历史文化背景', color: 'from-imperial-red to-pink-500' },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-gray-800 to-black" />

      {/* Animated Background Circles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full opacity-10"
            style={{
              width: `${300 + i * 200}px`,
              height: `${300 + i * 200}px`,
              background: 'radial-gradient(circle, rgba(212, 175, 55, 0.3) 0%, transparent 70%)',
              left: '50%',
              top: '50%',
              marginLeft: `-${(300 + i * 200) / 2}px`,
              marginTop: `-${(300 + i * 200) / 2}px`,
            }}
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.1, 0.2, 0.1],
            }}
            transition={{
              duration: 4 + i,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 py-32 text-center">
        {/* Main Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center gap-2 px-4 py-2 mb-6 bg-imperial-gold/10 border border-imperial-gold/30 rounded-full"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <span className="w-2 h-2 bg-imperial-gold rounded-full animate-pulse" />
            <span className="text-imperial-gold text-sm font-medium">2026计算机设计大赛参赛作品</span>
          </motion.div>

          <h1 className="text-5xl md:text-7xl font-bold mb-6">
            <span className="bg-gradient-to-r from-imperial-gold via-white to-imperial-gold bg-clip-text text-transparent">
              古建智识
            </span>
          </h1>

          <p className="text-xl md:text-2xl text-gray-300 mb-4">
            AI驱动的中国古代建筑智能识别系统
          </p>

          <p className="text-gray-400 max-w-2xl mx-auto mb-12">
            上传古建筑照片，AI 自动识别建筑类型、年代、风格特征
            <br />
            并在3D场景中沉浸式展示，让您深入了解中华建筑文化之美
          </p>
        </motion.div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              className="group relative p-6 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden hover:border-imperial-gold/50 transition-all duration-300"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.1 }}
              whileHover={{ scale: 1.02, y: -5 }}
            >
              {/* Gradient Background on Hover */}
              <div className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />

              {/* Icon */}
              <motion.div
                className={`w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br ${feature.color} flex items-center justify-center shadow-lg`}
                whileHover={{ rotate: 10, scale: 1.1 }}
              >
                <feature.icon className="w-8 h-8 text-white" />
              </motion.div>

              <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400 text-sm">{feature.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* CTA Button */}
        <motion.button
          onClick={onScrollToApp}
          className="group relative px-8 py-4 bg-gradient-to-r from-imperial-gold to-imperial-red text-white font-bold rounded-full overflow-hidden shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          {/* Shine Effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />

          <span className="relative flex items-center gap-2">
            <Camera className="w-5 h-5" />
            开始体验
          </span>
        </motion.button>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <ChevronDown className="w-8 h-8 text-imperial-gold/50" />
        </motion.div>
      </div>
    </section>
  );
};