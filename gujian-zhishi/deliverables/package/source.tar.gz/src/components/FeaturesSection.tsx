import { motion } from 'framer-motion';
import { Camera, Brain, Box, Zap, Shield, Clock } from 'lucide-react';

const features = [
  {
    icon: Camera,
    title: '智能图像识别',
    description: '基于智谱清言 GLM-4V 大模型，精准识别古建筑的类型、年代、风格特征，支持民居、官府、皇宫、桥梁等多种建筑类别。',
    color: 'from-blue-500 to-cyan-500',
    gradient: 'bg-gradient-to-br from-blue-500/20 to-cyan-500/20',
  },
  {
    icon: Box,
    title: '3D 沉浸体验',
    description: 'Three.js + WebGPU 构建的高性能 3D 场景，支持 360° 旋转、缩放、平移，让您身临其境般欣赏古建筑之美。',
    color: 'from-amber-500 to-orange-500',
    gradient: 'bg-gradient-to-br from-amber-500/20 to-orange-500/20',
  },
  {
    icon: Brain,
    title: '知识图谱',
    description: '丰富的古建筑知识库，涵盖历史背景、建筑特点、文化价值等多维度信息，AI 智能推荐相关知识。',
    color: 'from-purple-500 to-pink-500',
    gradient: 'bg-gradient-to-br from-purple-500/20 to-pink-500/20',
  },
  {
    icon: Zap,
    title: '极速响应',
    description: '优化的前端架构和 AI 调用策略，秒级返回识别结果，流畅的用户体验。',
    color: 'from-green-500 to-emerald-500',
    gradient: 'bg-gradient-to-br from-green-500/20 to-emerald-500/20',
  },
  {
    icon: Shield,
    title: '隐私保护',
    description: '本地处理图片数据，不上传原始图片到服务器，保护您的隐私和数据安全。',
    color: 'from-red-500 to-rose-500',
    gradient: 'bg-gradient-to-br from-red-500/20 to-rose-500/20',
  },
  {
    icon: Clock,
    title: '历史回溯',
    description: '支持 1911 年前的中国古代建筑识别，涵盖明清、宋元等多个历史时期的建筑风格。',
    color: 'from-indigo-500 to-violet-500',
    gradient: 'bg-gradient-to-br from-indigo-500/20 to-violet-500/20',
  },
];

export const FeaturesSection: React.FC = () => {
  return (
    <section id="features" className="relative py-32 bg-black overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      </div>

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <motion.span
            className="inline-block px-4 py-2 mb-6 text-sm font-medium text-amber-400 bg-amber-400/10 border border-amber-400/20 rounded-full"
          >
            核心功能
          </motion.span>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            强大功能，<span className="text-gradient-gold">一触即达</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            融合前沿 AI 技术与精美交互设计，为您打造极致的古建筑探索体验
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative"
            >
              <div className="relative p-8 h-full bg-white/[0.02] backdrop-blur-sm border border-white/5 rounded-2xl hover:border-white/10 transition-all duration-500 card-hover overflow-hidden">
                {/* Hover Gradient */}
                <div className={`absolute inset-0 ${feature.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                
                {/* Icon */}
                <div className={`relative w-14 h-14 mb-6 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>

                {/* Content */}
                <h3 className="relative text-xl font-bold text-white mb-3 group-hover:text-amber-300 transition-colors">
                  {feature.title}
                </h3>
                <p className="relative text-gray-400 leading-relaxed">
                  {feature.description}
                </p>

                {/* Corner Decoration */}
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-white/5 to-transparent rounded-bl-full opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};