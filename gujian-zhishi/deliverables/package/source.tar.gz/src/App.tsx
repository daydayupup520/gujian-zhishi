import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { NewNavbar } from './components/NewNavbar';
import { NewHeroSection } from './components/NewHeroSection';
import { FeaturesSection } from './components/FeaturesSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { ShowcaseSection } from './components/ShowcaseSection';
import { TechStackSection } from './components/TechStackSection';
import { NewFooter } from './components/NewFooter';
import { BuildingDiagnosisSection } from './components/BuildingDiagnosisSection';
import { InnovationLabSection } from './components/InnovationLabSection';
import { HistoricalGISSection } from './components/HistoricalGISSection';
import { VisualizationLabSection } from './components/VisualizationLabSection';
import { BuildingComparison } from './components/BuildingComparison';
import { GlassImageUploader } from './components/GlassImageUploader';
import { GlassRecognitionResult } from './components/GlassRecognitionResult';
import { Scene3D } from './components/Scene3D';
import { LoadingAnimation } from './components/LoadingAnimation';
import {
  recognizeBuildingMulti,
  mockRecognizeBuilding,
  fileToBase64Many,
} from './lib/ai/recognition';
import type { RecognitionResult } from './types/ai';
import { Building, Camera, BookOpen } from 'lucide-react';

import './styles/custom.css';

function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<RecognitionResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = useCallback(async (files: File[], previews: string[]) => {
    void previews;
    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const apiKey = import.meta.env.VITE_ZHIPU_API_KEY;
      let recognitionResult: RecognitionResult;

      if (apiKey && apiKey !== '把你的API密钥填在这里') {
        const base64List = await fileToBase64Many(files);
        recognitionResult = await recognizeBuildingMulti(base64List);
      } else {
        console.log('未配置 API Key，使用模拟数据');
        recognitionResult = await mockRecognizeBuilding(files.length);
      }

      setResult(recognitionResult);
    } catch (err) {
      console.error('识别失败:', err);
      setError(err instanceof Error ? err.message : '识别失败，请重试');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <NewNavbar />
      <NewHeroSection />
      <FeaturesSection />
      <HowItWorksSection />

      <section id="app" className="relative py-32 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <motion.span className="inline-block px-4 py-2 mb-6 text-sm font-medium text-amber-400 bg-amber-400/10 border border-amber-400/20 rounded-full">
              立即体验
            </motion.span>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              开始 <span className="text-gradient-gold">多视角识别</span> 古建筑
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              上传同一建筑的多个角度图片，AI 将进行融合识别并输出部件级细节与历史 GIS 语境
            </p>
          </motion.div>

          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="mb-8 p-4 bg-red-900/30 border border-red-500/50 rounded-xl text-red-200 text-center"
              >
                {error}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="p-8 bg-white/[0.02] backdrop-blur-sm border border-white/5 rounded-2xl">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-yellow-500 flex items-center justify-center">
                    <Camera className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">多图上传</h3>
                    <p className="text-sm text-gray-400">支持多角度 JPG、PNG</p>
                  </div>
                </div>
                <GlassImageUploader onImageUpload={handleImageUpload} isLoading={isLoading} />
              </div>

              <div className="mt-6">
                <GlassRecognitionResult result={result} isLoading={isLoading} />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="p-8 bg-white/[0.02] backdrop-blur-sm border border-white/5 rounded-2xl">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                      <Building className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">3D 展示</h3>
                      <p className="text-sm text-gray-400">沉浸式浏览体验</p>
                    </div>
                  </div>
                  {result && (
                    <span className="px-3 py-1 bg-amber-500/20 text-amber-400 rounded-full text-sm">
                      {result.category}
                    </span>
                  )}
                </div>
                <Scene3D
                  key={`${result?.name ?? 'default'}-${result?.category ?? '其他'}-${result?.location ?? '未知'}`}
                  buildingName={result?.name || '古建筑展示'}
                  buildingCategory={result?.category}
                  buildingEra={result?.era}
                  buildingLocation={result?.location}
                  highlights={result?.features}
                />
              </div>

              <AnimatePresence>
                {result && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 20 }}
                    className="mt-6 p-6 bg-white/[0.02] backdrop-blur-sm border border-white/5 rounded-2xl"
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center">
                        <BookOpen className="w-5 h-5 text-white" />
                      </div>
                      <h4 className="text-lg font-bold">建筑知识</h4>
                    </div>
                    <p className="text-gray-300 leading-relaxed mb-4">{result.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {Array.from(new Set(result.features)).map((feature) => (
                        <span
                          key={feature}
                          className="px-3 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-full text-sm"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>

          <BuildingDiagnosisSection result={result} />
          <InnovationLabSection result={result} />
          <HistoricalGISSection result={result} />
          <VisualizationLabSection result={result} />
          <BuildingComparison />
        </div>
      </section>

      <ShowcaseSection />
      <TechStackSection />
      <NewFooter />

      <AnimatePresence>{isLoading && <LoadingAnimation isLoading={isLoading} />}</AnimatePresence>
    </div>
  );
}

export default App;
